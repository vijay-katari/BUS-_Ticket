import React from 'react';

export default function AdminDashboard() {
  return (
    <div>
      <h3>Admin Dashboard</h3>
      <ul>
        <li>Manage Buses</li>
        <li>Manage Routes</li>
        <li>Schedule Trips</li>
        <li>Reports</li>
      </ul>
    </div>
  );
}
