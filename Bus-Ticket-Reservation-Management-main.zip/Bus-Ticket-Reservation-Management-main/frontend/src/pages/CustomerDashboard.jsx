import React from 'react';

export default function CustomerDashboard() {
  return (
    <div>
      <h3>My Bookings</h3>
      <p>Upcoming and past trips will be listed here.</p>
    </div>
  );
}
