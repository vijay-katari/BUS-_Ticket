Place your scanner.png image in this folder.
The Ticket page references /assets/scanner.png as a placeholder for the entry scanner.
