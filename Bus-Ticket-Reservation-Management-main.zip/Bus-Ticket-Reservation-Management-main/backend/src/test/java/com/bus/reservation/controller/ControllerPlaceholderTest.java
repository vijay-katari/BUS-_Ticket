package com.bus.reservation.controller;

import org.junit.jupiter.api.Test;

class ControllerPlaceholderTest {
    @Test
    void placeholder() {
        // add MVC tests later
    }
}

