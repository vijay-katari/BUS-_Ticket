package com.bus.reservation.repository;

import org.junit.jupiter.api.Test;

class RepositoryPlaceholderTest {
    @Test
    void placeholder() {
        // add repository tests later
    }
}

