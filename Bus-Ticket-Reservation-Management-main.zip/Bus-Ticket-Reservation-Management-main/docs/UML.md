# UML Diagrams

- High-level Context Diagram
- Use Case Diagram (Customer/Admin)
- Class Diagram (core entities/services)
- Sequence Diagrams (Search, Booking, Payment)
